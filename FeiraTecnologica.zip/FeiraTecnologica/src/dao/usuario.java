package dao;

import factory.ConnectionFactory;
import modelo.*;
import java.sql.*;
import java.sql.PreparedStatement;

public class usuario {

    public static Connection conector() {

        java.sql.Connection conexao = null;
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost/ida";
        String user = "root";
        String password = "";
        
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }
}
