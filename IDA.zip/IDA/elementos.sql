-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 09-Nov-2021 às 02:28
-- Versão do servidor: 10.4.20-MariaDB
-- versão do PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tabela`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `elementos`
--

CREATE TABLE `elementos` (
  `ID_Elementos` varchar(30) DEFAULT NULL,
  `ID_Professor_c` varchar(30) DEFAULT NULL,
  `Num_atomico` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `elementos`
--

INSERT INTO `elementos` (`ID_Elementos`, `ID_Professor_c`, `Num_atomico`) VALUES
('Hidrogênio', '', 1),
('Hidrogênio', '', 1),
('Hélio', '', 2),
('Lítio', '', 3),
('Berílio', '', 4),
('Boro', '', 5),
('Carbono', '', 6),
('Nitrogênio', '', 7),
('Oxigênio', '', 8),
('Flúor', '', 9),
('Neônio', '', 10),
('Sódio', '', 11),
('Magnésio', '', 12),
('Alumínio', '', 13),
('Silício', '', 14),
('Fósforo', '', 15),
('Enxofre', '', 16),
('Cloro', '', 17),
('Argônio', '', 18),
('Potássio', '', 19),
('Cálcio', '', 20),
('Escândio', '', 21),
('Titânio', '', 22),
('Vanádio', '', 23),
('Cromo', '', 24),
('Manganês', '', 25),
('Ferro', '', 26),
('Cobalto', '', 27),
('Níquel', '', 28),
('Cobre', '', 29),
('Zinco', '', 30),
('Gálio', '', 31),
('Germânio', '', 32),
('Arsênio', '', 33),
('Selênio', '', 34),
('Bromo', '', 35),
('Criptônio', '', 36),
('Rubídio', '', 37),
('Estrônico', '', 38),
('Ítrio', '', 39),
('Zircônio', '', 40),
('Nióbio', '', 41),
('Molibdênio', '', 42),
('Tecnécio', '', 43),
('Rutênio', '', 44),
('Ródio', '', 45),
('Paládio', '', 46),
('Prata', '', 47),
('Cádmio', '', 48),
('Índio', '', 49),
('Estanho', '', 50),
('Antimônio', '', 51),
('Telúrio', '', 52),
('Iodo', '', 53),
('Xenônio', '', 54),
('Césio', '', 55),
('Hidrogênio', '', 1),
('Hélio', '', 2),
('Lítio', '', 3),
('Berílio', '', 4),
('Boro', '', 5),
('Carbono', '', 6),
('Nitrogênio', '', 7),
('Oxigênio', '', 8),
('Flúor', '', 9),
('Neônio', '', 10),
('Sódio', '', 11),
('Magnésio', '', 12),
('Alumínio', '', 13),
('Silício', '', 14),
('Fósforo', '', 15),
('Enxofre', '', 16),
('Cloro', '', 17),
('Argônio', '', 18),
('Potássio', '', 19),
('Cálcio', '', 20),
('Escândio', '', 21),
('Titânio', '', 22),
('Vanádio', '', 23),
('Cromo', '', 24),
('Manganês', '', 25),
('Ferro', '', 26),
('Cobalto', '', 27),
('Níquel', '', 28),
('Cobre', '', 29),
('Zinco', '', 30),
('Gálio', '', 31),
('Germânio', '', 32),
('Arsênio', '', 33),
('Selênio', '', 34),
('Bromo', '', 35),
('Criptônio', '', 36),
('Rubídio', '', 37),
('Estrônico', '', 38),
('Ítrio', '', 39),
('Zircônio', '', 40),
('Nióbio', '', 41),
('Molibdênio', '', 42),
('Tecnécio', '', 43),
('Rutênio', '', 44),
('Ródio', '', 45),
('Paládio', '', 46),
('Prata', '', 47),
('Cádmio', '', 48),
('Índio', '', 49),
('Estanho', '', 50),
('Antimônio', '', 51),
('Telúrio', '', 52),
('Iodo', '', 53),
('Xenônio', '', 54),
('Césio', '', 55),
('Bário', '', 56),
('Latânio', '', 57),
('Cério', '', 58),
('Praseodímio', '', 59),
('Neodímio', '', 60),
('Promécio', '', 61),
('Samário', '', 62),
('Európio', '', 63),
('Gadolínio', '', 64),
('Térbio', '', 65),
('Disprósio', '', 66),
('Hólmio', '', 67),
('Érbio', '', 68),
('Túlio', '', 69),
('Itérbio', '', 70),
('Lutécio', '', 71),
('Háfnio', '', 72),
('Tântalo', '', 73),
('Tungstênio', '', 74),
('Rênio', '', 75),
('Ósmio', '', 76),
('Irídio', '', 77),
('Platina', '', 78),
('Ouro', '', 79),
('Mercúrio', '', 80),
('Tálio', '', 81),
('Chumbo', '', 82),
('Bismuto', '', 83),
('Polônio', '', 84),
('Ástato', '', 85),
('Radônio', '', 86),
('Frâncio', '', 87),
('Rádio', '', 88),
('Actínio', '', 89),
('Tório', '', 90),
('Protactínio', '', 91),
('Netúnio', '', 93),
('Plutônio', '', 94),
('Amerício', '', 95),
('Cúrio', '', 96),
('Berquélio', '', 97),
('Califórnio', '', 98),
('Einsténio', '', 99),
('Férmio', '', 100),
('Mendelévio', '', 101),
('Nobélio', '', 102),
('Laurêncio', '', 103),
('Rutherfórdio', '', 104),
('Dúbnio', '', 105),
('Seabórgio', '', 106),
('Bóhrio', '', 107),
('Hássio', '', 108),
('Meitnério', '', 109),
('Darmstádio', '', 110),
('Roentgênio', '', 111),
('Copernício', '', 112),
('Nihônio', '', 113),
('Fleróvio', '', 114),
('Moscóvio', '', 115),
('Livermório', '', 116),
('Tenessino', '', 117),
('Organessônio', '', 118);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
